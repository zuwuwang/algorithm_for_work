#include <opencv2/opencv.hpp>  
#include <cstdio>  
#include <cstdlib>  
#include <Windows.h>  


//�ο�����:
//http://blog.csdn.net/masibuaa/article/details/14056807
//http://blog.csdn.net/icvpr/article/details/8454527
//http://blog.csdn.net/yeyang911/article/details/25645177
