I will try my best to finish the original DPM algorithm.

This program will be the most efficient code of complete-DPM realization.
The many techniques used here belong to all the past endeavour in writing DPM codes and my graduation essay.

Target: 
Original DPM; very much Efficient; Able to Process Images of Different Sizes Continuously; 
Using MutltiThread, No Parallel Calculation; A Solution Both for Windows and Linux;
Good Readability; Easy to Use.

by: Yu Xianguo, 2013/11/14, NUDT, ALV lab.

///////////////////////////////////////////////////////////////////

Yu Xianguo, 2014/5/5, 1308 lab:

This version of FastDPM is revised from the 2013-12 version.
I will replace the directory manipulation function with boost library to the one depending on standard c library.